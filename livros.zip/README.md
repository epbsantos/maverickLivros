Book Preview with BookBlock
=========

A "look inside" book preview with BookBlock. A concept for book showcases or online book stores that shows a grid of books with the options to view the details and to look inside of the book, opening the BookBlock in fullscreen and allowing for a 3D page navigation.

[Article on Codrops](http://tympanus.net/codrops/?p=18228)

[Demo](http://tympanus.net/Development/BookPreview/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".

[Backpack Illustration by Tom Loots](http://dribbble.com/shots/1365305-Herschel-backpack-freebie)
[Boy portrait by CI W P](http://www.flickr.com/photos/wilhelminah/9647840662/) [Attribution-ShareAlike 2.0 Generic (CC BY-SA 2.0)](http://creativecommons.org/licenses/by-sa/2.0/deed.en)
[Library photo by Germán Póo-Caamaño](http://www.flickr.com/photos/gpoo/9004993292/) [Attribution 2.0 Generic (CC BY 2.0)](http://creativecommons.org/licenses/by/2.0/deed.en)

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2013](http://www.codrops.com)








